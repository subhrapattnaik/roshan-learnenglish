import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Signin from "./screens/Signin"
import Register from "./screens/Register"
import { NavigationContainer } from '@react-navigation/native';
import Home from "./screens/Homescreen"
import { createStackNavigator } from "@react-navigation/stack";
import Dictionary from "./screens/Dictionary"
import Pronounciation from "./screens/Pronounciation"



import firebase from "firebase";
import { firebaseConfig } from "./config";


if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
} else {
  firebase.app();
}

const Stack = createStackNavigator();

const StackNav = () => {
  return(
  <Stack.Navigator initialRouteName="Signin"  screenOptions={{
    headerShown: true,
    gestureEnabled: false
  }}>
    <Stack.Screen name="Signin" component={Signin} />
    <Stack.Screen name="Register" component={Register} />
    <Stack.Screen name="Home" component={Home} />
    <Stack.Screen name="Dictionary" component={Dictionary} />
        <Stack.Screen name="Pronounciation" component={Pronounciation} />
  </Stack.Navigator>)
}

export default function App() {
  return (
    <NavigationContainer>
      <StackNav/>
    </NavigationContainer>)

}
