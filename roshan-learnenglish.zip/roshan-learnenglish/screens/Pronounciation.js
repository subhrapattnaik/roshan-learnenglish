import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import { Header } from 'react-native-elements';

import * as Speech from 'expo-speech';

export default class Pronounciation extends React.Component {
  constructor() {
    super();
    this.state = {
      isSearchedPressed: false,
      word: 'loading....',
      lexicalCategory: '',
      examples: '',
      definition: '',
    };
  }

  async initiateTTS(word) {
    console.log(word);

    Speech.speak(word);
  }

  render() {
    return (
      <View>
        <Header
          backgroundColor={'pink'}
          centerComponent={{
            text: ' Pronounciation',

            style: {
              color: 'white',
              fontSize: 20,
              fontFamily: 'Stint Ultra Condensed',
            },
          }}
        />

        <TextInput
          style={styles.inputBox}
          placeholder=""
          onChangeText={(text) => {
            this.setState({
              text: text,
            });
          }}
        />

        <TouchableOpacity onPress={() => this.initiateTTS(this.state.text)}>
          <Text style={styles.textIn}> Click to Listen </Text>{' '}
        </TouchableOpacity>



         <TouchableOpacity
            onPress={() => this.props.navigation.navigate("Home")}
          >
            <Text style={styles.buttonTextNewUser}>Go to Home Page </Text>
          </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  inputBox: {
    marginTop: 50,
    width: '80%',
    alignSelf: 'center',
    height: 40,
    textAlign: 'center',
    borderWidth: 4,
    borderColor: 'black',
    outline: 'none',
  },

  textIn: {
    textAlign: 'center',
    fontFamily: 'times',
    fontSize: 25,
    alignSelf: 'center',
    fontWeight: 'bold',
  },
});
