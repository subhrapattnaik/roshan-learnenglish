/*export const firebaseConfig = {

  apiKey: "AIzaSyCjhp-Z1fbUMo4dKGDMpPC1Kz-4gSbkx18",

  authDomain: "dummy-9bad7.firebaseapp.com",

  databaseURL: "https://dummy-9bad7-default-rtdb.firebaseio.com",

  projectId: "dummy-9bad7",

  storageBucket: "dummy-9bad7.appspot.com",

  messagingSenderId: "50230926718",

  appId: "1:50230926718:web:74716f7f7bf773b790a72f"

};*/


export const firebaseConfig = {
  apiKey: 'AIzaSyDkZh41OPKmiaQFM2eiIRiXNSyyHCuUVSQ',
  authDomain: 'ownapp-2fdee.firebaseapp.com',
  databaseURL: 'https://ownapp-2fdee-default-rtdb.firebaseio.com',
  projectId: 'ownapp-2fdee',
  storageBucket: 'ownapp-2fdee.appspot.com',
  messagingSenderId: '194587732665',
  appId: '1:194587732665:web:6afc456d74e145e5f98968',
};
/*
export const firebaseConfig = {
  apiKey: "AIzaSyBC65tMIPj19owcexs5XnOtcPSNVesLxjw",
  authDomain: "myownapp-cbe86.firebaseapp.com",
  databaseURL: "https://myownapp-cbe86-default-rtdb.firebaseio.com",
  projectId: "myownapp-cbe86",
  storageBucket: "myownapp-cbe86.appspot.com",
  messagingSenderId: "299330759448",
  appId: "1:299330759448:web:93c863e860d6501db8cc6d"
};
*/